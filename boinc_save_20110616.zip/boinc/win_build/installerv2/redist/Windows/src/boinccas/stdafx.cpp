// stdafx.cpp : source file that includes just the standard includes
// NativeImage.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file

const char *BOINC_RCSID_be7b382649="$Id: stdafx.cpp 7985 2005-09-13 09:01:56Z ballen $";
