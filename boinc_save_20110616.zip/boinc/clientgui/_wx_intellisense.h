/*
 * This file enables intellisense for wxWindows. It is included in the project,
 * but never actually included in any cpp source.
 *
 * It needs to be opened once to create the *.ncb file.
 * You can close this file now.
 * 
 * NOTE: To enable intellisense for your other projects, copy this file to the project
 * and include it in your workspace. Then open the file and close it again to give
 * Visual Studio the opportunity to parse the file and add its contents to intellisense.
 */
#include <wx/msw/__wx_intellisense_inc.h>

