go to slots/0 and type ./run for version 6 (Raspberry Pi) or ./run.v5 for Dreamplug

