go to slots/0 and type ./run

