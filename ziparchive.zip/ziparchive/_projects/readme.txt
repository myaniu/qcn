Copy appropriate project files to the main ZipArchive Library sources folder.
The main folder already contains Visual Studio 2005 project files by default.