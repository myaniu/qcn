////////////////////////////////////////////////////////////////////////////////
// This source file is part of the ZipArchive library source distribution and
// is Copyrighted 2000 - 2007 by Artpol Software - Tadeusz Dracz
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// For the licensing details refer to the License.txt file.
//
// Web Site: http://www.artpol-software.com
////////////////////////////////////////////////////////////////////////////////


/**
* \file ZipCompatibility.h
* ZipCompatibility namespace declaration.
*
*/

#if !defined(ZIPARCHIVE_ZIPCOMPATIBILITY_DOT_H)
#define ZIPARCHIVE_ZIPCOMPATIBILITY_DOT_H

#if _MSC_VER > 1000
#pragma once
#endif

class CZipAutoBuffer;
class CZipFileHeader;

#include "ZipString.h"

/**
	Includes functions that provide support for the proper conversion of attributes 
	and filenames between different system platforms.
*/
namespace ZipCompatibility  
{
	/**
		The codes of the compatibility of the file attribute information.

		\see
			CZipArchive::GetSystemCompatibility
		\see
			CZipFileHeader::GetSystemCompatibility
		\see
			ZipPlatform::GetSystemID
	*/
	enum ZipPlatforms
	{		   
			   zcDosFat,		///< MS-DOS and OS/2 (FAT / VFAT / FAT32 file systems)
               zcAmiga,			///< Amiga 
               zcVaxVms,		///< VAX/VMS
               zcUnix,			///< Unix / Linux
               zcVmCms,			///< VM/CMS
               zcAtari,			///< Atari ST
               zcOs2Hpfs,		///< OS/2 H.P.F.S.
               zcMacintosh,		///< Macintosh 
               zcZsystem,		///< Z-System
               zcCpm,			///< CP/M 
               zcNtfs			///< Windows NTFS
	};

	/**
		Checks whether the system with the given code is supported by the ZipArchive Library.

		\param iCode
			One of the #ZipPlatforms values to check.

		\return
			\c true, if supported; \c false otherwise.
	*/
	bool IsPlatformSupported(int iCode);

	/**
		Converts the system attributes between different system platforms.

		\param uAttr
			The attributes to convert.

		\param iFromSystem
			The system code to convert \a uAttr from.

		\param iToSystem
			The system code to convert \a uAttr to.

		\return
			The converted attributes.

		\note
			Throws exceptions.

		\see
			ZipPlatforms
	*/
	DWORD ConvertToSystem(DWORD uAttr, int iFromSystem, int iToSystem);

	/**
		Converts the string stored in \a buffer using the given code page.

		\param buffer
			The buffer to convert the string from.

		\param szString
			The string to receive the result.

		\param uCodePage
			The code page used in conversion.

		\see
			<a href="kb">0610051525</a>
	*/
	void ConvertBufferToString(CZipString& szString, const CZipAutoBuffer& buffer, UINT uCodePage);
	
	/**
		Converts the \a lpszString using the given code page.

		\param lpszString
			The string to convert from.

		\param buffer
			The buffer to receive the result.

		\param uCodePage
			The code page used in conversion.

		\see
			<a href="kb">0610051525</a>
	*/
	void ConvertStringToBuffer(LPCTSTR lpszString, CZipAutoBuffer& buffer, UINT uCodePage);

	/**
		Changes the path separators from slash to backslash or vice-versa in \a szFileName.

		\param szFileName
			The filename to have the path separators changed.

		\param	bReplaceSlash
			If \c true, changes slash to backslash. If \c false, changes backslash to slash.
	*/
	void SlashBackslashChg(CZipString& szFileName, bool bReplaceSlash);
};

#endif // !defined(ZIPARCHIVE_ZIPCOMPATIBILITY_DOT_H)
