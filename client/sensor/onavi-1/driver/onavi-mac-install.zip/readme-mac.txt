Simply run the install script from a Terminal window prompt.

$   ./install-mac.sh

You will be prompted for your password
to run as an "Administrator" (super-user).  If the current account does not have "sudo"/super-user
privileges you will need to install this from an account that does.  The computer will
be rebooted after the script finishes.

