11/20/2009	

This driver is for the XR21V141x USB UART product family.  This driver has been WHQL certified for XP/2K/Vista/7 and is version 1.2.0.0.  
This zip file includes both 32-bit and 64-bit drivers. 

The "x64" folder contains the 64-bit driver for 64-bit systems.
The "x86" folder contains the 32-bit driver for 32-bit systems.

For driver source code, please send an e-mail request to support@o-navi.COM.  The Software License Agreement (SLA) will be sent to you 
for review.  Once the SLA is complete, the driver source code will be sent to you.  