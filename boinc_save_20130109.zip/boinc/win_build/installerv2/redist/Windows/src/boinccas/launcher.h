
#pragma once

HRESULT CreateProcessWithExplorerIL(LPWSTR szProcessName, LPWSTR szCmdLine);
